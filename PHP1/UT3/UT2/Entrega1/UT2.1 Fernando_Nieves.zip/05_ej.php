<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

    <?php

    $a = 1 + 2;
    $a = 2 - 1;
    $a = 2 * 3;
    $a = 10 % 3;
    $a = 10 / 3;
    $a = 1 ** 2;
    $a = 2 + 3 * 3;
    $a = (2 + 3) * 3;
    $a = 1*(2+3)/3;

    $a = 1 / 3;

    $a = "aa" . "aaa";

    ?>

</body>

</html>