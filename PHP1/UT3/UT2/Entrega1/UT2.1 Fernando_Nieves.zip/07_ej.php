<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
    $a;
    echo $a;

    // Aparece el error: Warning: Undefined variable $a in 
    // C:\Users\ferna\Desktop\Daw\Entorno Servidor\xampp\htdocs\UT2\Entrega1\07_ej.php on line 13
    
    
    ?>
</body>

</html>