<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
    $a = 0;
    $b;
    echo $a + $b;

    // Aparece el error: Warning: Undefined variable $b in 
    //C:\Users\ferna\Desktop\Daw\Entorno Servidor\xampp\htdocs\UT2\Entrega1\08_ej.php on line 14
    // Aun así devuelve el valor: 0
    
    ?>
</body>

</html>