<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php 

    echo 5+6.0; // Funciona y devuelve 11
    echo 2 + "hola"; // Deja de funcionar
    echo 5 + "mundo"; // Deja de funcionar

?>
</body>
</html>