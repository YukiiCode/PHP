<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php 
    // Al ser un lenguaje interpretado, se hace todo en tiempo de ejecución por lo que 
    // es menos restrictivo, y mas rapido al ejecutarse
    ?>
</body>
</html>