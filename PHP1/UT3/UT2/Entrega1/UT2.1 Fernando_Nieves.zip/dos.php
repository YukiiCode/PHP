<?php
include("uno.php");

echo $hola;
echo $mundo;

?>