<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
    echo "<table border='1px solid black'> <tr><td>";
    include("uno.php");
    include("03_ej.php");
    echo "<td>";
    include("dos.php");
    echo "<tr><td>";
    include("02_ej.php");
    echo "<td>";
    include("03_ej.php");
    
    ?>
</body>

</html>