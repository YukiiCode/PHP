<?php 
$hola= "ola";
$mundo= "mundo";
?>