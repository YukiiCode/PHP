<!DOCTYPE html>
<html>
<head>
    <title>Factura #<?php echo e($cuota->id); ?></title>
</head>
<body>
    <h2>Factura #<?php echo e($cuota->id); ?></h2>
    <p>Hola <?php echo e($cuota->cliente->nombre); ?>,</p>
    
    <p>Adjunto encontrará su factura por un monto de <?php echo e(number_format($cuota->monto, 2)); ?>€.</p>
    
    <p>Detalles:
        <ul>
            <li>Tipo: <?php echo e(ucfirst($cuota->tipo)); ?></li>
            <li>Estado: <?php echo e(ucfirst($cuota->estado)); ?></li>
            <li>Fecha de emisión: <?php echo e($cuota->fecha_emision); ?></li>
        </ul>
    </p>
    
    <p>Saludos cordiales,<br>El equipo de administración</p>
</body>
</html><?php /**PATH C:\Users\ferna\Documents\GitHub\PHP\Proyecto-2\resources\views/emails/invoice.blade.php ENDPATH**/ ?>