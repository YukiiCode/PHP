<?php $__env->startSection('contenido'); ?>
<div class="container mt-4">
    <h2 class="mb-4">Listado de Empleados</h2>
    
    <div class="table-responsive">
        <table class="table table-bordered table-hover table-striped">
            <thead class="thead-dark">
                <tr>
                    <th>Nombre</th>
                    <th>Apellidos</th>
                    <th>Email</th>
                    <th>Teléfono</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr data-toggle="collapse" data-target="#detalles<?php echo e($empleado->id); ?>" style="cursor: pointer;">
                    <td><?php echo e($empleado->nombre); ?></td>
                    <td><?php echo e($empleado->apellidos); ?></td>
                    <td><?php echo e($empleado->email); ?></td>
                    <td><?php echo e($empleado->telefono); ?></td>
                    <td>
                        <div class="btn-group" role="group">
                            <a href="<?php echo e(route('empleados.edit', $empleado->id)); ?>" class="btn btn-primary btn-sm me-1">Editar</a>
                            <form action="<?php echo e(route('empleados.destroy', $empleado->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Eliminar empleado?')">Eliminar</button>
                            </form>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td colspan="5" class="hidden-row">
                        <div id="detalles<?php echo e($empleado->id); ?>" class="collapse">
                            <p><strong>Dirección:</strong> <?php echo e($empleado->direccion); ?></p>
                            <p><strong>Fecha Nacimiento:</strong> <?php echo e($empleado->fecha_nacimiento); ?></p>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>



<style>
.hidden-row { padding: 0 !important; }
.table-hover tbody tr:hover { background-color: #f8f9fa; }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ferna\Documents\GitHub\PHP\Proyecto-2\resources\views/ver_empleados.blade.php ENDPATH**/ ?>