<?php $__env->startSection('contenido'); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Editar Cuota</h1>
    
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-edit me-1"></i>
            Modificar Cuota #<?php echo e($cuota->id); ?>

        </div>
        
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('cuotas.update', $cuota->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Concepto</label>
                        <input type="text" class="form-control" name="concepto" 
                            value="<?php echo e(old('concepto', $cuota->concepto)); ?>" required>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label">Tipo de Cargo</label>
                        <select class="form-select" name="tipo" required>
                            <option value="individual" <?php echo e($cuota->tipo == 'individual' ? 'selected' : ''); ?>>Normal</option>
                            <option value="mensual" <?php echo e($cuota->tipo == 'mensual' ? 'selected' : ''); ?>>Mensual</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Importe</label>
                        <div class="input-group">
                            <input type="number" class="form-control" name="importe" 
                                step="0.01" value="<?php echo e(old('importe', $cuota->importe)); ?>" required>
                            <span class="input-group-text">€</span>
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <label class="form-label">Fecha Emisión</label>
                        <input type="date" class="form-control" name="fecha_emision" 
                            value="<?php echo e(old('fecha_emision', $cuota->fecha_emision->format('Y-m-d'))); ?>">
                    </div>
                    
                    <div class="col-md-4">
                        <label class="form-label">Fecha Pago</label>
                        <input type="date" class="form-control" name="fecha_pago" 
                            value="<?php echo e(old('fecha_pago', optional($cuota->fecha_pago)?->format('Y-m-d'))); ?>">
                    </div>
                    
                    <div class="col-md-4">
                        <label class="form-label">Estado</label>
                        <select class="form-select" id="estado" name="estado" required>
                            <option value="pendiente" <?php echo e(old('estado', $cuota->estado) == 'pendiente' ? 'selected' : ''); ?>>Pendiente</option>
                            <option value="pagado" <?php echo e(old('estado', $cuota->estado) == 'pagado' ? 'selected' : ''); ?>>Pagado</option>
                        </select>
                    </div>
                    
                    <div class="col-12">
                        <label class="form-label">Notas</label>
                        <textarea class="form-control" name="notas" rows="3"><?php echo e(old('notas', $cuota->notas)); ?></textarea>
                    </div>
                </div>

                <?php if($errors->any()): ?>
                <div class="alert alert-danger mt-4">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>

                <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i> Guardar Cambios
                    </button>
                    <a href="<?php echo e(route('cuotas.index')); ?>" class="btn btn-secondary">
                        Cancelar
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ferna\Documents\GitHub\PHP\Proyecto-2\resources\views/cuotas/edit.blade.php ENDPATH**/ ?>