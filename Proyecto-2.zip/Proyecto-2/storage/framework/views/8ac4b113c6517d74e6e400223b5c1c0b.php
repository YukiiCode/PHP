<?php $__env->startSection('titulo', 'Listado de Tareas'); ?>
<?php $__env->startSection('contenido'); ?>
<div class="container mt-5">
    <div class="card shadow-lg">
        <div class="card-header bg-primary text-white">
            <h3 class="card-title mb-0"><i class="fas fa-tasks mr-2"></i> Listado Tareas</h3>
        </div>
        <div class="card-body">

            <!-- Tabla de Tareas -->
            <div class="table-responsive">
                <table class="table table-hover table-bordered mb-0">
                    <thead class="thead-light">
                        <tr>
                            <th class="text-center">Id</th>
                            <th class="text-center">Estado</th>
                            <th class="text-center">Operario</th>
                            <th class="text-center">Creación</th>
                            <th class="text-center">Finalización</th>
                            <th class="text-center">Anotaciones</th>
                            <th class="text-center">Cliente</th>
                            <th class="text-center" style="width: 150px;">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="<?php if(request()->query('id') == $tarea->id): ?> table-active <?php endif; ?>">
                            <td class="text-center"><?php echo e($tarea->id); ?></td>
                            <td class="text-center">
                                <?php
                                $estados = [
                                'F' => ['descripcion' => 'Finalizada', 'clase' => 'bg-success'],
                                'T' => ['descripcion' => 'En proceso', 'clase' => 'bg-warning'],
                                'C' => ['descripcion' => 'Cancelada', 'clase' => 'bg-danger'],
                                'A' => ['descripcion' => 'Por Aprobar', 'clase' => 'bg-secondary'],
                                'E' => ['descripcion' => 'Pausada', 'clase' => 'bg-info'],
                                ];
                                $estadoActual = $estados[$tarea->estado] ?? ['descripcion' => 'Desconocido', 'clase' => 'badge-dark'];
                                ?>
                                <span class="badge badge-pill <?php echo e($estadoActual['clase']); ?>">
                                    <?php echo e($estadoActual['descripcion']); ?>

                                </span>
                            </td>
                            <td> <?php echo e($tarea->empleado ? $tarea->empleado->nombre : 'N/A'); ?> </td>
                            <td class="text-center"><?php echo e(\Carbon\Carbon::parse($tarea->fecha_creacion)->format('d/m/Y H:i')); ?></td>
                            <td class="text-center"><?php echo e($tarea->fecha_finalizacion ? \Carbon\Carbon::parse($tarea->fecha_finalizacion)->format('d/m/Y H:i') : ''); ?></td>
                            <td>
                                <span data-toggle="tooltip" title="<?php echo e($tarea->anotaciones); ?>">
                                    <?php echo e(Str::limit($tarea->anotaciones, 30)); ?>

                                </span>
                            </td>
                            <td> 
                                <a href="<?php echo e(route('tareas.cliente-detail',['id' => $tarea->cliente_id])); ?>" 
                                   class="btn btn-outline-info btn-sm text-decoration-none"
                                   data-toggle="tooltip" 
                                   title="Ver detalles del cliente">
                                    <i class="fas fa-user mr-1"></i>
                                    <?php echo e($tarea->cliente ? $tarea->cliente->nombre : 'N/A'); ?>

                                </a>
                            </td>
                            <td class="text-center">
                                <div class="btn-group" role="group">
                                    <?php if(Auth::user()->empleado->tipo !== 'operario'): ?>
                                        <a href="<?php echo e(route('tareas.edit',['id' => $tarea->id])); ?>" class="btn btn-outline-primary btn-sm" data-toggle="tooltip" title="Editar">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                    <?php endif; ?>
                                    <a href="<?php echo e(route('tareas.confirm-delete', ['id' => $tarea->id,'page'=> request()->query('page')])); ?>"
                                        class="btn btn-outline-danger btn-sm"
                                        data-toggle="tooltip"
                                        title="Eliminar">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                    <a href="<?php if(request()->query('id') == $tarea->id): ?> <?php echo e(route('tareas.index', ['page'=> request()->query('page')])); ?> <?php else: ?> <?php echo e(route('tareas.index', ['id'=>$tarea->id, 'page'=>request()->query('page')])); ?> <?php endif; ?>"
                                        class="btn btn-outline-secondary btn-sm"
                                        data-toggle="tooltip"
                                        title="<?php if(request()->query('id') == $tarea->id): ?> Ocultar detalles <?php else: ?> Ver detalles <?php endif; ?>">
                                        <i class="fas <?php if(request()->query('id') == $tarea->id): ?> fa-chevron-up <?php else: ?> fa-chevron-down <?php endif; ?>"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php if(request()->query('id') == $tarea->id): ?>
                        <tr class="table-info">
                            <td colspan="8">
                                <div class="p-3">
                                    <h5 class="mb-3"><i class="fas fa-file-alt mr-2"></i>Detalles adicionales</h5>

                                    <?php if($tarea->archivos && count($tarea->archivos) > 0): ?>
                                    <div class="row">
                                        <?php $__currentLoopData = $tarea->archivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                        $archivoUrl = Storage::url($archivo->ruta);
                                        $extension = pathinfo($archivo->ruta, PATHINFO_EXTENSION);
                                        ?>

                                        <div class="col-md-4 mb-3">
                                            <div class="card h-100 shadow-sm">
                                                <div class="card-body text-center">
                                                    <?php if($extension === 'pdf'): ?>
                                                    <div class="pdf-container">
                                                        <iframe src="<?php echo e($archivoUrl); ?>" class="pdf-viewer mb-2" frameborder="0"></iframe>
                                                        <div class="btn-group mt-2">
                                                            <a href="<?php echo e($archivoUrl); ?>" target="_blank" class="btn btn-outline-danger btn-sm">
                                                                <i class="fas fa-external-link-alt mr-1"></i>Abrir
                                                            </a>
                                                            <a href="<?php echo e($archivoUrl); ?>" download class="btn btn-outline-danger btn-sm">
                                                                <i class="fas fa-download mr-1"></i>Descargar
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <?php elseif(in_array($extension, ['jpg','jpeg','png','gif'])): ?>
                                                    <img src="<?php echo e($archivoUrl); ?>" class="img-thumbnail mb-2" style="max-height: 150px;">
                                                    <a href="<?php echo e($archivoUrl); ?>" download class="btn btn-outline-primary btn-sm btn-block">
                                                        <i class="fas fa-download mr-1"></i>Descargar imagen
                                                    </a>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <?php else: ?>
                                    <div class="alert alert-info mb-0">
                                        <i class="fas fa-info-circle mr-2"></i>No hay archivos adjuntos para esta tarea
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center py-4">
                                <h4 class="text-muted"><i class="fas fa-inbox mr-2"></i>No se encontraron tareas</h4>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Paginación -->
            <div class="d-flex justify-content-center mt-4">
                <?php echo e($tareas->links('vendor.pagination.bootstrap-4')); ?>

            </div>
        </div>
    </div>
</div>

<?php if(Request::is('confirmar-borrado-tarea/*')): ?>
<?php    
$id = Request::route('id'); // Obtiene el ID de la ruta
$tarea = $tareas->firstWhere('id', $id);
?>
<div class="modal fade show" tabindex="-1" role="dialog" style="display: block;">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content shadow-lg">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">Confirmar Borrado</h5>
                <a href="<?php echo e(route('tareas.index', ['page'=> request()->query('page')])); ?>" class="btn-close btn-close-white" aria-label="Close"></a>
            </div>
            <div class="modal-body">
                <p class="mb-3">¿Estás seguro de que deseas borrar la siguiente tarea?</p>
                <?php if(isset($tarea)): ?>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item"><strong>ID:</strong> <?php echo e($tarea->id); ?></li>
                    <li class="list-group-item"><strong>Estado:</strong> <?php echo e($tarea->estado); ?></li>
                    <li class="list-group-item"><strong>Operario:</strong> <?php echo e($tarea->empleado ? $tarea->empleado->nombre : 'N/A'); ?></li>
                    <li class="list-group-item"><strong>Creación:</strong> <?php echo e(\Carbon\Carbon::parse($tarea->fecha_creacion)->format('d/m/Y H:i')); ?></li>
                    <li class="list-group-item"><strong>Finalización:</strong> <?php echo e($tarea->fecha_finalizacion ? \Carbon\Carbon::parse($tarea->fecha_finalizacion)->format('d/m/Y H:i') : 'N/A'); ?></li>
                    <li class="list-group-item"><strong>Anotaciones:</strong> <?php echo e(Str::limit($tarea->anotaciones, 30)); ?></li>
                    <li class="list-group-item"><strong>Cliente:</strong> <?php echo e($tarea->cliente ? $tarea->cliente->nombre : 'N/A'); ?></li>
                </ul>
                <?php else: ?>
                <p class="text-muted">No se encontró la tarea.</p>
                <?php endif; ?>
            </div>
            <div class="modal-footer">
                <a href="<?php echo e(route('tareas.index', ['page'=> request()->query('page')])); ?>" class="btn btn-secondary">Cancelar</a>
                <form action="<?php echo e(route('tareas.destroy', ['id' => $id])); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Sí, borrar</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if(Request::is('ver-tareas/detalle-cliente/*')): ?>   
<?php
$id = Request::route('id'); // Obtiene el ID de la ruta
$cliente = $tareas->firstWhere('cliente_id', $id)->cliente;
?>
<div class="modal fade show" tabindex="-1" role="dialog" style="display: block;">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content shadow-lg">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">Detalles del Cliente</h5>
                <a href="<?php echo e(route('tareas.index',['page'=> request()->query('page')])); ?>" class="btn-close btn-close-white" aria-label="Close"></a>
            </div>
            <div class="modal-body">
                <?php if(isset($cliente)): ?>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item"><strong>ID:</strong> <?php echo e($cliente->id); ?></li>
                    <li class="list-group-item"><strong>Nombre:</strong> <?php echo e($cliente->nombre); ?></li>
                    <li class="list-group-item"><strong>CIF:</strong> <?php echo e($cliente->cif); ?></li>
                    <li class="list-group-item"><strong>Teléfono:</strong> <?php echo e($cliente->telefono); ?></li>
                    <li class="list-group-item"><strong>Correo Electrónico:</strong> <?php echo e($cliente->correo); ?></li>
                    <li class="list-group-item"><strong>Dirección:</strong> <?php echo e($cliente->direccion ?? 'N/A'); ?></li>
                    <li class="list-group-item"><strong>Fecha de Registro:</strong> <?php echo e(\Carbon\Carbon::parse($cliente->created_at)->format('d/m/Y H:i')); ?></li>
                </ul>
                <?php else: ?>
                <p class="text-muted">No se encontró el cliente.</p>
                <?php endif; ?>
            </div>
            <div class="modal-footer">
                <a href="<?php echo e(route('tareas.index', ['page'=> request()->query('page')])); ?>" class="btn btn-secondary">Cerrar</a>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ferna\Documents\GitHub\PHP\Proyecto-2\resources\views/ver_tareas.blade.php ENDPATH**/ ?>