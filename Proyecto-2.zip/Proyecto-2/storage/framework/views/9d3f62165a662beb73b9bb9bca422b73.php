
<?php $__env->startSection('titulo', 'Editar Tarea'); ?>
<?php $__env->startSection('contenido'); ?>
<div class="container">
    <h1 class="my-4">Editar Tarea</h1>

    <!-- Mostrar errores de validación -->
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Por favor, corrige los siguientes errores:</strong>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>

    <form action="<?php echo e(route('actualizar-tarea', ['id' => $tarea->id])); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?> <!-- Indica que esta es una solicitud de actualización -->

        <!-- Operario -->
        <div class="mb-3">
            <label for="operario" class="form-label">Operario Encargado <span class="text-danger">*</span></label>
            <select class="form-select <?php $__errorArgs = ['operario_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="operario_id" id="operario" required>
                <option value="">Selecciona un operario</option>
                <?php $__currentLoopData = $operarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($operario->id); ?>" <?php echo e($tarea->operario_id == $operario->id ? 'selected' : ''); ?>>
                    <?php echo e($operario->nombre); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['operario_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Fecha de Realización -->
        <div class="mb-3">
            <label for="fecha_realizacion" class="form-label">Fecha de Realización <span class="text-danger">*</span></label>
            <input type="date" class="form-control <?php $__errorArgs = ['fecha_realizacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                name="fecha_realizacion" id="fecha_realizacion"
                value="<?php echo e(old('fecha_realizacion', \Carbon\Carbon::parse($tarea->fecha_realizacion)->format('Y-m-d'))); ?>" required>
            <?php $__errorArgs = ['fecha_realizacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Cliente -->
        <div class="mb-3">
            <label for="cliente" class="form-label">Cliente</label>
            <select class="form-select" name="cliente_id" id="cliente">
                <option value="">Selecciona un cliente</option>
                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($cliente->id); ?> <?php if($cliente->id == $tarea->cliente->id): ?> echo selected <?php endif; ?>"><?php echo e($cliente->nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- Estado -->
        <div class="mb-3">
            <label for="estado" class="form-label">Estado <span class="text-danger">*</span></label>
            <select class="form-select <?php $__errorArgs = ['estado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="estado" id="estado" required>
                <option value="">Selecciona un estado</option>
                <option value="F" <?php echo e($tarea->estado == 'F' ? 'selected' : ''); ?>>Finalizado</option>
                <option value="T" <?php echo e($tarea->estado == 'T' ? 'selected' : ''); ?>>Trabajando</option>
                <option value="C" <?php echo e($tarea->estado == 'C' ? 'selected' : ''); ?>>Cancelado</option>
                <option value="E" <?php echo e($tarea->estado == 'E' ? 'selected' : ''); ?>>En Espera</option>
            </select>
            <?php $__errorArgs = ['estado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Anotaciones -->
        <div class="mb-3">
            <label for="anotaciones" class="form-label">Anotaciones</label>
            <textarea class="form-control <?php $__errorArgs = ['anotaciones'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                name="anotaciones" id="anotaciones" rows="3"><?php echo e(old('anotaciones', $tarea->anotaciones)); ?></textarea>
            <?php $__errorArgs = ['anotaciones'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Subida de Resumen PDF -->
        <div class="mb-3">
            <label for="fichero_resumen" class="form-label">Fichero Resumen (PDF)</label>
            <input type="file" class="form-control <?php $__errorArgs = ['fichero_resumen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                name="fichero_resumen" id="fichero_resumen" accept=".pdf">
            <?php $__errorArgs = ['fichero_resumen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <!-- Mostrar el PDF actual -->
            <?php if($tarea->fichero_resumen): ?>
            <div class="mt-3">
                <strong>Previsualización del PDF actual:</strong>
                <div class="mt-2">
                    <iframe src="<?php echo e(Storage::url($tarea->fichero_resumen)); ?>"
                        style="width: 70%; height: 500px; border: 1px solid #ccc;"
                        frameborder="0"></iframe>
                </div>
            </div>
            <?php endif; ?>

        </div>

        <!-- Subida de Fotos -->
        <div class="mb-3">
            <label for="fotos_trabajo" class="form-label">Fotos del Trabajo (Imágenes)</label>
            <input type="file" class="form-control <?php $__errorArgs = ['fotos_trabajo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                name="fotos_trabajo[]" id="fotos_trabajo" multiple accept="image/*">
            <?php $__errorArgs = ['fotos_trabajo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <?php if($tarea->fotos_trabajo && count($tarea->fotos_trabajo) > 0): ?>
            <div class="mt-2">
                <strong>Fotos actuales:</strong>
                <div class="row">
                    <?php $__currentLoopData = $tarea->fotos_trabajo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 mb-3">
                        <div class="card h-100 shadow-sm align-items-center">
                            <img src="<?php echo e(Storage::url($foto)); ?>" class="card-img-top img-thumbnail " style="max-height: 100px; width: 70%;">
                            <div class="card-body p-2">
                                <a href="<?php echo e(Storage::url($foto)); ?>" download class="btn btn-primary btn-sm w-100">
                                    <i class="fas fa-download me-1"></i> Descargar
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Botón de Envío -->
        <div class="d-flex gap-2">
            <button type="submit" class="btn btn-primary" data-bs-toggle="tooltip" title="Guardar cambios">
                <i class="fas fa-save me-1"></i> Actualizar Tarea
            </button>
            <a href="<?php echo e(route('ver-tareas')); ?>" class="btn btn-secondary" data-bs-toggle="tooltip" title="Cancelar edición">
                <i class="fas fa-times me-1"></i> Cancelar
            </a>
        </div>
    </form>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ferna\Documents\GitHub\PHP\Proyecto-2\resources\views/editar_tarea.blade.php ENDPATH**/ ?>