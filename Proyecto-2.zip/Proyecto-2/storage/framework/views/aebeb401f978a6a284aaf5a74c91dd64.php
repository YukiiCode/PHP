<?php $__env->startSection('contenido'); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Gestión de Cuotas</h1>
    
    <div class="card mb-4">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <div class="me-3">
                    <i class="fas fa-table me-1"></i>
                    Listado de Cuotas
                </div>
                <div class="dropdown">
                    <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-plus me-1"></i> Añadir Cuotas
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownMenuButton">
                        <li>
                            <a class="dropdown-item" href="<?php echo e(route('cuotas.create')); ?>">
                                <i class="fas fa-user me-1"></i> Cuota Individual
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="<?php echo e(route('cuotas.batch.create')); ?>">
                                <i class="fas fa-users me-1"></i> Remesa para Todos los Clientes
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="card-body">
            <div class="mb-3">
                <form class="row g-2">
                    <div class="col-md-3">
                        <input type="text" class="form-control" placeholder="Buscar cliente..." name="search">
                    </div>
                    <div class="col-md-2">
                        <select class="form-select" name="estado">
                            <option value="">Todos los estados</option>
                            <option value="pendiente">Pendiente</option>
                            <option value="pagado">Pagado</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <input type="month" class="form-control" name="mes">
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary">Filtrar</button>
                    </div>
                </form>
            </div>

            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>Cliente</th>
                            <th>Concepto</th>
                            <th>Tipo</th>
                            <th>Importe</th>
                            <th>Fecha Emisión</th>
                            <th>Estado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $cuotas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="<?php echo e($cuota->estado === 'pagado' ? 'table-success' : 'table-warning'); ?>">
                            <td><?php echo e($cuota->cliente->nombre ?? 'Cliente no encontrado'); ?></td>
                            <td><?php echo e($cuota->concepto); ?></td>
                            <td><?php echo e(ucfirst($cuota->tipo)); ?></td>
                            <td><?php echo e(number_format($cuota->importe, 2)); ?>€</td>
                            <td><?php echo e($cuota->fecha_emision->format('d/m/Y')); ?></td>
                            <td>
                                <span class="badge bg-<?php echo e($cuota->estado === 'pagado' ? 'success' : 'warning'); ?>">
                                    <?php echo e(ucfirst($cuota->estado)); ?>

                                </span>
                            </td>
                            <td>
                                <a href="<?php echo e(route('cuotas.edit', $cuota->id)); ?>" class="btn btn-sm btn-outline-secondary" title="Editar">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="<?php echo e(route('cuotas.download', $cuota->id)); ?>" class="btn btn-sm btn-outline-primary" title="Descargar PDF">
                                    <i class="fas fa-file-pdf"></i>
                                </a>
                                <form action="<?php echo e(route('cuotas.email', $cuota->id)); ?>" method="POST" style="display: inline-block;">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-info" title="Enviar por email">
                                        <i class="fas fa-envelope"></i>
                                    </button>
                                </form>
                                <button type="button" class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" 
                                    data-bs-target="#deleteModal<?php echo e($cuota->id); ?>">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<style>
    .modal-backdrop {
        z-index: 1040 !important;
    }
    .modal {
        z-index: 1050 !important;
    }
</style>

<!-- Delete Modals -->
<?php $__currentLoopData = $cuotas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="deleteModal<?php echo e($cuota->id); ?>" tabindex="-1" aria-labelledby="deleteModalLabel<?php echo e($cuota->id); ?>" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title" id="deleteModalLabel<?php echo e($cuota->id); ?>">Confirmar eliminación</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                ¿Estás seguro de eliminar la cuota de <?php echo e($cuota->cliente->nombre); ?> (<?php echo e($cuota->concepto); ?>)?
            </div>
            <div class="modal-footer">
                <form action="<?php echo e(route('cuotas.destroy', $cuota->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Eliminar</button>
                </form>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ferna\Documents\GitHub\PHP\Proyecto-2\resources\views/cuotas/index.blade.php ENDPATH**/ ?>