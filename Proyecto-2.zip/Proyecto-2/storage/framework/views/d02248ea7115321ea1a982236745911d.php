<?php $__env->startSection('contenido'); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Crear Nueva Cuota</h1>
    
    <div class="card mb-4">
        <div class="card-body">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="<?php echo e(route('cuotas.store')); ?>">
                <?php echo csrf_field(); ?>
                
                <div class="mb-3">
                    <label for="cliente_id" class="form-label">Cliente</label>
                    <select class="form-select" id="cliente_id" name="cliente_id" required>
                        <option value="">Seleccione un cliente</option>
                        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cliente->id); ?>" <?php echo e(old('cliente_id') == $cliente->id ? 'selected' : ''); ?>>
                                <?php echo e($cliente->nombre); ?> <?php echo e($cliente->apellidos); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="concepto" class="form-label">Concepto</label>
                    <input type="text" class="form-control" id="concepto" name="concepto" 
                           value="<?php echo e(old('concepto')); ?>" required maxlength="100">
                </div>

                <div class="mb-3">
                    <label for="monto" class="form-label">Importe (€)</label>
                    <input type="number" class="form-control" id="monto" name="monto"
                           step="0.01" min="0" value="<?php echo e(old('monto')); ?>" required>
                </div>
                
                <div class="mb-3">
                    <label for="tipo" class="form-label">Tipo de Cuota</label>
                    <select class="form-select" id="tipo" name="tipo" required>
                        <option value="mensual" <?php echo e(old('tipo') == 'mensual' ? 'selected' : ''); ?>>Mensual</option>
                        <option value="extraordinaria" <?php echo e(old('tipo') == 'extraordinaria' ? 'selected' : ''); ?>>Extraordinaria</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="fecha_emision" class="form-label">Fecha de Emisión</label>
                    <input type="date" class="form-control" id="fecha_emision" name="fecha_emision"
                           value="<?php echo e(old('fecha_emision', now()->format('Y-m-d'))); ?>" required>
                </div>
                
                <div class="mb-3">
                    <label for="estado" class="form-label">Estado</label>
                    <select class="form-select" id="estado" name="estado" required>
                        <option value="pendiente" <?php echo e(old('estado') == 'pendiente' ? 'selected' : ''); ?>>Pendiente</option>
                        <option value="pagada" <?php echo e(old('estado') == 'pagada' ? 'selected' : ''); ?>>Pagada</option>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary">Crear Cuota</button>
                <a href="<?php echo e(route('cuotas.index')); ?>" class="btn btn-secondary">Cancelar</a>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ferna\Documents\GitHub\PHP\Proyecto-2\resources\views/cuotas/create.blade.php ENDPATH**/ ?>