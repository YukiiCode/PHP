
<?php $__env->startSection('titulo', 'Listado de Clientes'); ?>
<?php $__env->startSection('contenido'); ?>
<div class="container-fluid p-4">
    <div class="card shadow border-0">
        <div class="card-header bg-primary text-white py-3">
            <h3 class="card-title mb-0 fs-4 fw-bold"><i class="fas fa-users me-2"></i>Gestión de Clientes</h3>
        </div>
        <div class="card-body"> 
            <div class="table-responsive">
                <table class="table table-striped table-hover align-middle mb-0">
                    <thead class="table-light align-middle">
                        <tr class="fs-7 text-uppercase">
                            <th class="ps-3">CIF</th>
                            <th>Nombre</th>
                            <th>Teléfono</th>
                            <th>Correo</th>
                            <th>País</th>
                            <th>Moneda</th>
                            <th>Importe Mensual</th>
                            <th class="text-center" style="width: 150px;">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="<?php if(request()->query('id') == $cliente->id): ?> table-active <?php endif; ?>">
                            <td><?php echo e($cliente->cif); ?></td>
                            <td><?php echo e($cliente->nombre); ?></td>
                            <td><?php echo e($cliente->telefono); ?></td>
                            <td><?php echo e($cliente->correo); ?></td>
                            <td><?php echo e($cliente->pais); ?></td>
                            <td><?php echo e($cliente->moneda); ?></td>
                            <td><?php echo e($cliente->importe_mensual); ?></td>
                            <td class="text-center">
                                <div class="btn-group btn-group-sm" role="group" aria-label="Acciones cliente">
                                    <a href="<?php echo e(route('ver-cliente', ['id' => $cliente->id])); ?>" 
                                       class="btn btn-outline-primary"
                                       data-bs-toggle="tooltip"
                                       data-bs-placement="top"
                                       title="Detalles completos">
                                        <i class="fas fa-eye me-1"></i>Ver
                                    </a>
                                    <button class="btn btn-outline-info"
                                        type="button"
                                        data-bs-toggle="collapse"
                                        data-bs-target="#cuotas-<?php echo e($cliente->id); ?>"
                                        aria-expanded="false"
                                        aria-controls="cuotas-<?php echo e($cliente->id); ?>"
                                        title="<?php echo e(request()->query('id') == $cliente->id ? 'Ocultar' : 'Mostrar'); ?> cuotas"
                                        aria-label="Gestión de cuotas">
                                        <i class="fas fa-coins me-1"></i>Cuotas
                                    </button>
                                    <form action="<?php echo e(route('clientes.destroy', $cliente->id)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" 
                                            class="btn btn-outline-danger"
                                            onclick="return confirm('¿Confirmar eliminación permanente?')"
                                            aria-label="Eliminar cliente">
                                            <i class="fas fa-trash-alt me-1"></i>Baja
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <tr class="collapse" id="cuotas-<?php echo e($cliente->id); ?>">
                            <td colspan="8" class="p-0">
                                <div class="p-3 bg-light">
                                    <h5 class="mb-3 text-primary fs-5"><i class="fas fa-coins me-2"></i>Historial de Cuotas</h5>
                                    <div class="table-responsive">
                                        <table class="table table-sm table-borderless mb-0">
                                            <thead class="small bg-soft-primary">
                                                <tr>
                                                    <th class="ps-3">Concepto</th>
                                                <th>Fecha Emisión</th>
                                                <th>Importe</th>
                                                <th>Pagado</th>
                                                <th>Fecha Pago</th>
                                                <th>Notas</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_2 = true; $__currentLoopData = $cliente->cuotas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                            <tr class="<?php echo e($cuota->pagado ? 'bg-success bg-opacity-25 text-dark' : 'bg-warning bg-opacity-25'); ?>">
                                                <td><?php echo e($cuota->concepto); ?></td>
                                                <td class="text-nowrap"><?php echo e(\Carbon\Carbon::parse($cuota->fecha_emision)->isoFormat('DD MMM YYYY')); ?></td>
                                                <td class="fw-medium"><?php echo e(number_format($cuota->importe, 2)); ?>€</td>
                                                <td>
                                                    <span class="badge bg-<?php echo e($cuota->pagado ? 'success' : 'warning'); ?> rounded-pill">
                                                        <?php echo e($cuota->pagado ? 'Pagado' : 'Pendiente'); ?>

                                                    </span>
                                                </td>
                                                <td><?php echo e($cuota->fecha_pago ? \Carbon\Carbon::parse($cuota->fecha_pago)->format('d/m/Y') : 'N/A'); ?></td>
                                                <td><?php echo e($cuota->notas); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                            <tr>
                                                <td colspan="6" class="text-center">No hay cuotas registradas para este cliente.</td>
                                            </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center py-4">
                                <h4 class="text-muted"><i class="fas fa-inbox mr-2"></i>No se encontraron clientes</h4>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="d-flex justify-content-between align-items-center mt-4 px-3">
                    <span class="text-muted small">Mostrando <?php echo e($clientes->firstItem()); ?> - <?php echo e($clientes->lastItem()); ?> de <?php echo e($clientes->total()); ?> registros</span>
                    <div class="d-flex">
                        <?php echo e($clientes->onEachSide(1)->links('vendor.pagination.bootstrap-5')); ?>

                    </div>
                </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ferna\Documents\GitHub\PHP\Proyecto-2\resources\views/ver_clientes.blade.php ENDPATH**/ ?>