<!DOCTYPE html>
<html>
<head>
    <title>Factura #<?php echo e($cuota->id); ?></title>
    <style>
        body { font-family: Arial, sans-serif; }
        .header { text-align: center; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <div class="header">
        <h2>Factura #<?php echo e($cuota->id); ?></h2>
        <p>Fecha de emisión: <?php echo e($cuota->fecha_emision); ?></p>
    </div>

    <div class="content">
        <h3>Cliente:</h3>
        <p><?php echo e($cuota->cliente->nombre); ?> <?php echo e($cuota->cliente->apellidos); ?></p>
        <p>Email: <?php echo e($cuota->cliente->email); ?></p>

        <h3>Detalles de la cuota:</h3>
        <table>
            <tr>
                <th>Tipo</th>
                <th>Monto</th>
                <th>Estado</th>
            </tr>
            <tr>
                <td><?php echo e(ucfirst($cuota->tipo)); ?></td>
                <td><?php echo e(number_format($cuota->importe, 2)); ?>€</td>
                <td><?php echo e(ucfirst($cuota->estado)); ?></td>
            </tr>
        </table>
    </div>
</body>
</html><?php /**PATH C:\Users\ferna\Documents\GitHub\PHP\Proyecto-2\resources\views/cuotas/invoice.blade.php ENDPATH**/ ?>