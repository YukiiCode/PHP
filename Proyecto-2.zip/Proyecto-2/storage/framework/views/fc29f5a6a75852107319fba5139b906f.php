<?php $__env->startSection('titulo', 'Editar Empleado'); ?>

<?php $__env->startSection('contenido'); ?>
<div class="container mt-5">
    <h2 class="text-center mb-4">Editar Empleado</h2>
    
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('empleados.update', $empleado->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                
                <div class="mb-3">
                    <label for="nombre" class="form-label">Nombre</label>
                    <input type="text" class="form-control" id="nombre" name="nombre" value="<?php echo e(old('nombre', $empleado->nombre)); ?>">
                </div>
                
                <div class="mb-3">
                    <label for="dni" class="form-label">DNI</label>
                    <input type="text" class="form-control" id="dni" name="dni" value="<?php echo e(old('dni', $empleado->dni)); ?>">
                </div>
                
                <div class="mb-3">
                    <label for="correo" class="form-label">Correo</label>
                    <input type="email" class="form-control" id="correo" name="correo" value="<?php echo e(old('correo', $empleado->correo)); ?>">
                </div>
                
                <div class="mb-3">
                    <label for="telefono" class="form-label">Teléfono</label>
                    <input type="tel" class="form-control" id="telefono" name="telefono" value="<?php echo e(old('telefono', $empleado->telefono)); ?>">
                </div>
                
                <div class="mb-3">
                    <label for="direccion" class="form-label">Dirección</label>
                    <input type="text" class="form-control" id="direccion" name="direccion" value="<?php echo e(old('direccion', $empleado->direccion)); ?>">
                </div>
                
                <div class="mb-3">
                    <label for="tipo" class="form-label">Tipo</label>
                    <select class="form-select" id="tipo" name="tipo">
                        <option value="operario" <?php echo e($empleado->tipo == 'operario' ? 'selected' : ''); ?>>Operario</option>
                        <option value="administrador" <?php echo e($empleado->tipo == 'administrador' ? 'selected' : ''); ?>>Administrador</option>
                    </select>
                </div>
                
                <div class="d-grid">
                    <button type="submit" class="btn btn-primary">Actualizar Empleado</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ferna\Documents\GitHub\PHP\Proyecto-2\resources\views/editar_empleado.blade.php ENDPATH**/ ?>