<?php

function validarFormulario($datos)
{
    $errores = [];

    // NIF/CIF
    if (empty($_POST['nif_cif'])) {
        $errores[] = "Campo 'NIF/CIF' vacío";
    } else if (!preg_match("/^([0-9]{8}[A-Z]|[ABCDEFGHJNPQRSUVW][0-9]{7}[0-9A-J])$/", $_POST['nif_cif']))
        $errores["Campo NIF/CIF inválido"];

    // Nombre
    if (empty($_POST['nombre'])) {
        $errores[] = "Campo 'Nombre' vacío";
    } else if (!preg_match("/^[a-zA-Z]+/", $_POST['nombre'])) {
        $errores[] = "Campo 'Nombre' inválido";
    }

    // Apellidos
    if (empty($_POST['apellidos'])) {
        $errores[] = "Campo 'Apellidos' vacío";
    } else if (!preg_match("/^[a-zA-Z]+/", $_POST['apellidos'])) {
        $errores[] = "Campo 'Apellidos' inválido <br>";
    }

    // Teléfono
    if (empty($_POST['telefono'])) {
        $errores[] = "Campo 'Apellidos' vacío";
    } else if (!preg_match("/^\+\d{1,3}[-\s]?\d{1,4}([-\s]?\d{3,4}){2,3}$/", $_POST['telefono'])) {
        $errores[] = "Campo 'Telefono' inválido (Ej: +34 666 66 66) <br>";
    }

    // Descripción
    if (empty($_POST['descripcion'])) {
        $errores[] = "Campo 'Descripción' vacío";
    } else if (!preg_match("/^[a-zA-Z]+/", $_POST['descripcion'])) {
        $errores[] = "Sólo se permiten letras en el apellido <br>";
    }

    // Email
    if (empty($_POST['email'])) {
        $errores[] = "Campo 'Correo electrónico' vacío";
    } else if (!preg_match("/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/", $_POST['email'])) {
        $errores[] = "Campo 'Correo electrónico' inválido<br>";
    }

    // Direccion
    if (empty($_POST['direccion'])) {
        $errores[] = "Campo 'Dirección' vacío";
    }

    // Poblacion
    if (empty($_POST['poblacion'])) {
        $errores[] = "Campo 'Población' vacío";
    }

    // Codigo postal
    if (empty($_POST['codigo_postal'])) {
        $errores[] = "Campo 'Código Postal' vacío";
    } else if (!preg_match("/^(0[1-9]|[1-4][0-9]|5[0-2])\d{3}$/", $_POST['codigo_postal'])) {
        $errores[] = "Campo 'Codigo Postal' inválido<br>";
    }

    // Provincia (select)
    if (empty($_POST['provincia'])) {
        $errores[] = "Niguna provincia seleccionada";
    }

    // Estado
    // Automatico: Esperando a ser aprobada
    $_POST['estado'] = "B";

    // Fecha de creacion
    // Se hace con la fecha actual en sql

    // Operario (select)
    if (empty($_POST['operario'])) {
        $errores[] = "Campo 'Operarios' vacío";
    }

    // Fecha realización
    if (empty($_POST['fecha_realizacion'])) {
        $errores[] = "Campo 'Fecha de Realización' vacío<br>";
    } else if (!preg_match("/^(0[1-9]|[12][0-9]|3[01])\/(0[1-9]|1[0-2])\/(19|20)\d{2}$/", $_POST['estado'])) {
        $errores[] = "Campo 'Fecha de Realización' inválido<br>";
    }

    // Anotaciones posteriores
    if (!empty($_POST['anotaciones_posteriores'])) {
        $errores[] = "Anotaciones posteriores: No se pueden añadir hasta que esté finalizada";
    }

    return $errores;
}
